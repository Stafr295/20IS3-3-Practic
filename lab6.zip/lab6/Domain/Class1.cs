﻿namespace Domain
{
    public class Class1
    {

    }
}